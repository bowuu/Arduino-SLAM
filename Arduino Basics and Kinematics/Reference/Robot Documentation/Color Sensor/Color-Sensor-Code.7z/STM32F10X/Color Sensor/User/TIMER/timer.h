#ifndef __TIMER_H
#define __TIMER_H

#include "stm32f10x.h"

void timer_init(u16 rld,u16 psc);

#endif


