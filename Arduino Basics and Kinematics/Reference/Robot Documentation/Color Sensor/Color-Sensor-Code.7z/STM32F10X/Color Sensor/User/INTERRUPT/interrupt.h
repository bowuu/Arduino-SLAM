#ifndef __INTERRUPT_H
#define __INTERRUPT_H

#include "stm32f10x.h"

extern u16 dat;
void int_init(void);

#endif

