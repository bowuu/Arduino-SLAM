#include "timer.h"
#include "interrupt.h"
#include <stdio.h>

u8 i;
u16 adj_num;
u16 dat_v[3];
float adj_v[3];
u16 adj_temp[3];
u8 adj_en;
void timer_init(u16 rld,u16 psc)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);

	TIM_TimeBaseInitStruct.TIM_Prescaler=psc;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period=rld;
	TIM_TimeBaseInitStruct.TIM_ClockDivision=TIM_CKD_DIV1;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);

	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);

	NVIC_InitStructure.NVIC_IRQChannel=TIM3_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=3;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority=3;
	NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;

	NVIC_Init(&NVIC_InitStructure);

	TIM_Cmd(TIM3,ENABLE);
}

void TIM3_IRQHandler(void)   
{
	if (TIM_GetITStatus(TIM3,TIM_IT_Update)!=RESET)  
	{
		i++;
		if(i>=3)
			i=0;
		if(i==0) //set the filter to red
		{
			GPIO_ResetBits(GPIOA,GPIO_Pin_3|GPIO_Pin_4);
			//read blue value
			dat_v[2]=dat;
			dat=0;
			if(adj_en)
			{
				dat_v[2]=(u16)((float)dat_v[2]*adj_v[2]/10.0);
				printf("Blue=%d-%d\r\n",dat_v[2]/256,dat_v[2]%256);
			}
			else
			{
				adj_temp[2]+=dat_v[2];
			}
		}			
		else if(i==1) //set the filter to green
		{
			GPIO_SetBits(GPIOA,GPIO_Pin_3|GPIO_Pin_4);
			//read red value
			dat_v[0]=dat;
			dat=0;
			if(adj_en)
			{
				dat_v[0]=(u16)((float)dat_v[0]*adj_v[0]/10.0);
				printf("Red=%d-%d\r\n",dat_v[0]/256,dat_v[0]%256);
			}
			else
			{
				adj_temp[0]+=dat_v[0];
			}
		}
		else  //set the filter to blue
		{
			GPIO_SetBits(GPIOA,GPIO_Pin_4);
			GPIO_ResetBits(GPIOA,GPIO_Pin_3);
			//read green value
			dat_v[1]=dat;
			dat=0;
			if(adj_en)
			{
				dat_v[1]=(u16)((float)dat_v[1]*adj_v[1]/10.0);
				printf("Green=%d-%d\r\n",dat_v[1]/256,dat_v[1]%256);
			}
			else
			{
				adj_temp[1]+=dat_v[1];
			}
		}
		if(!adj_en)
		{
			if(adj_num>=300)
			{
				adj_v[0]=(float)adj_temp[0]/100.0;
				adj_v[0]=255.0/adj_v[0]*10.0;
				adj_v[1]=(float)adj_temp[1]/100.0;
				adj_v[1]=255.0/adj_v[1]*10.0;
				adj_v[2]=(float)adj_temp[2]/100.0;
				adj_v[2]=255.0/adj_v[2]*10.0;
				adj_en=1;
			}
			else
			{
			 	adj_num++;
			}
		}		
		TIM_ClearITPendingBit(TIM3,TIM_IT_Update);   
	}
}
